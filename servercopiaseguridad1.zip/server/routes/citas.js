const express = require("express");
const { z } = require("zod");
const { connect, oidMaybe } = require("../lib/mongo");

const router = express.Router();

// === Schemas ===
const Proc = z.object({
  nombre: z.string().min(1),
  costo_unitario: z.number().nonnegative(),
  cantidad: z.number().int().positive().optional().default(1),
});

const CitaCreate = z.object({
  fecha: z.preprocess((v) => new Date(v), z.date()),
  paciente_id: z.string().min(1), // cédula (string) — decisión actual
  usuario_id: z.string().regex(/^[0-9a-fA-F]{24}$/),
  estado: z.enum(["Programada","Completada","Cancelada","NoAsistio"]).optional(),
  motivo: z.string().optional(),
  procedimientos: z.array(Proc).optional(),
  total: z.number().nonnegative().optional(),
});

// === POST /api/citas ===
router.post("/", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("citas");

    const parsed = CitaCreate.parse(req.body);

    const usuarioOid = oidMaybe(parsed.usuario_id);
    if (!usuarioOid) throw new Error("usuario_id inválido");

    const procs = (parsed.procedimientos || []).map(p => ({
      nombre: p.nombre.trim(),
      costo_unitario: Number(p.costo_unitario),
      cantidad: p.cantidad ?? 1
    }));

    const totalCalc = procs.reduce((acc, p) => acc + p.costo_unitario * (p.cantidad ?? 1), 0);
    const doc = {
      fecha: parsed.fecha,
      paciente_id: parsed.paciente_id.trim(),
      usuario_id: usuarioOid,
      estado: parsed.estado || "Programada",
      motivo: parsed.motivo?.trim() || null,
      procedimientos: procs,
      total: parsed.total ?? totalCalc,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    const r = await col.insertOne(doc);
    return res.status(201).json({ ok: true, id: r.insertedId.toString() });
  } catch (e) {
    return res.status(400).json({ ok: false, error: e.message });
  }
});

// === GET /api/citas ===
// Filtros opcionales: ?paciente_id=...&usuario_id=...&desde=YYYY-MM-DD&hasta=YYYY-MM-DD
router.get("/", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("citas");

    const { paciente_id, usuario_id, desde, hasta } = req.query;
    const q = {};
    if (paciente_id) q.paciente_id = String(paciente_id);
    if (usuario_id) {
      const oid = oidMaybe(usuario_id);
      if (!oid) return res.status(400).json({ ok: false, error: "usuario_id inválido" });
      q.usuario_id = oid;
    }
    if (desde || hasta) {
      q.fecha = {};
      if (desde) q.fecha.$gte = new Date(`${desde}T00:00:00`);
      if (hasta) q.fecha.$lte = new Date(`${hasta}T23:59:59`);
    }

    const docs = await col.find(q).sort({ fecha: -1 }).limit(100).toArray();
    return res.json({ ok: true, data: docs });
  } catch (e) {
    return res.status(500).json({ ok: false, error: e.message });
  }
});

module.exports = router;
