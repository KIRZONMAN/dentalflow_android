const express = require("express");
const { z } = require("zod");
const { connect } = require("../lib/mongo");

const router = express.Router();

// === Schemas ===
const ProcRealizado = z.object({
  tratamiento: z.string().min(1),
  fecha: z.preprocess((v) => new Date(v), z.date()),
  odontologo: z.string().optional(),
  resultado: z.string().optional()
});

// Permite 1 o varios
const HistoriaAppend = z.object({
  paciente_id: z.string().min(1),
  procedimiento: ProcRealizado.optional(),
  procedimientos_realizados: z.array(ProcRealizado).optional()
}).refine(v => v.procedimiento || (v.procedimientos_realizados && v.procedimientos_realizados.length), {
  message: "Debe incluir 'procedimiento' o 'procedimientos_realizados'"
});

// === GET /api/historias/:paciente_id ===
router.get("/:paciente_id", async (req, res) => {
  try {
    const db = await connect();
    const h = await db.collection("historias_clinicas").findOne({ paciente_id: String(req.params.paciente_id) });
    if (!h) return res.status(404).json({ ok: false, error: "Historia no encontrada" });
    res.json({ ok: true, data: h });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// === POST /api/historias (append upsert) ===
router.post("/", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("historias_clinicas");
    const parsed = HistoriaAppend.parse(req.body);

    const items = parsed.procedimientos_realizados ?? (parsed.procedimiento ? [parsed.procedimiento] : []);
    const now = new Date();

    const r = await col.updateOne(
      { paciente_id: parsed.paciente_id.trim() },
      {
        $setOnInsert: { paciente_id: parsed.paciente_id.trim(), createdAt: now },
        $push: { procedimientos_realizados: { $each: items } },
        $set: { updatedAt: now }
      },
      { upsert: true }
    );

    res.status(200).json({ ok: true, upserted: !!r.upsertedId, added: items.length });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

module.exports = router;
