const express = require("express");
const { z } = require("zod");
const { connect, oidMaybe } = require("../lib/mongo");

const router = express.Router();

const Producto = z.object({
  tipo_producto: z.string().min(1),
  especificaciones: z.string().optional(),
  cantidad: z.number().int().positive().default(1)
});

const OrdenLabCreate = z.object({
  cita_id: z.string().regex(/^[0-9a-fA-F]{24}$/),
  usuario_id: z.string().regex(/^[0-9a-fA-F]{24}$/),
  fecha_creacion: z.preprocess((v) => (v ? new Date(v) : new Date()), z.date()).optional(),
  estado: z.enum(["Pendiente","En producción","Entregada","Cancelada"]).default("Pendiente"),
  productos: z.array(Producto).min(1),
  observaciones: z.any().optional()
});

router.post("/", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("ordenes_laboratorio");

    const parsed = OrdenLabCreate.parse(req.body);
    const citaOid = oidMaybe(parsed.cita_id);
    const usuarioOid = oidMaybe(parsed.usuario_id);
    if (!citaOid || !usuarioOid) throw new Error("cita_id/usuario_id inválidos");

    const productos = parsed.productos.map(p => ({
      tipo_producto: p.tipo_producto.trim(),
      especificaciones: p.especificaciones?.trim() || null,
      cantidad: p.cantidad
    }));

    const doc = {
      cita_id: citaOid,
      usuario_id: usuarioOid,
      fecha_creacion: parsed.fecha_creacion || new Date(),
      estado: parsed.estado,
      observaciones: parsed.observaciones ?? null,
      productos,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    const r = await col.insertOne(doc);
    res.status(201).json({ ok: true, id: r.insertedId.toString() });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

// GET /api/ordenes-laboratorio?cita_id=...&desde=...&hasta=...
router.get("/", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("ordenes_laboratorio");
    const { cita_id, desde, hasta } = req.query;
    const q = {};
    if (cita_id) {
      const coid = oidMaybe(cita_id);
      if (!coid) return res.status(400).json({ ok: false, error: "cita_id inválido" });
      q.cita_id = coid;
    }
    if (desde || hasta) {
      q.fecha_creacion = {};
      if (desde) q.fecha_creacion.$gte = new Date(`${desde}T00:00:00`);
      if (hasta) q.fecha_creacion.$lte = new Date(`${hasta}T23:59:59`);
    }
    const docs = await col.find(q).sort({ fecha_creacion: -1 }).limit(100).toArray();
    res.json({ ok: true, data: docs });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

module.exports = router;
