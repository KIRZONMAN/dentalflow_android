const express = require("express");
const router = express.Router();
const { connect } = require("../lib/mongo");
const { pacienteSchemaUpsert, normalizePaciente } = require("../lib/validate");

// POST /api/pacientes  (upsert por _id = cédula)
router.post("/", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("pacientes");
    const parsed = pacienteSchemaUpsert.parse(req.body);
    const norm = normalizePaciente(parsed);

    // Fechas como Date, no string
    const now = new Date();
    const r = await col.updateOne(
      { _id: norm._id },
      {
        $setOnInsert: { createdAt: now },
        $set: { ...norm, updatedAt: now },
      },
      { upsert: true }
    );

    res
      .status(r.upsertedCount ? 201 : 200)
      .json({ ok: true, upserted: !!r.upsertedCount });
  } catch (e) {
    res.status(400).json({ ok: false, error: e.message });
  }
});

module.exports = router;
