const express = require("express");
const router = express.Router();
const { connect, oidMaybe } = require("../lib/mongo");
const {
  usuarioSchemaCreate,
  usuarioSchemaPatch,
} = require("../lib/validate");
const { normalizeRole } = require("../lib/roles");

// GET /api/usuarios?search=
router.get("/", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("usuarios");
    const search = (req.query.search || "").trim();

    const q = search
      ? {
          $or: [
            { nombres:   { $regex: search, $options: "i" } },
            { apellidos: { $regex: search, $options: "i" } },
            { correo:    { $regex: search, $options: "i" } },
            { rol:       { $regex: search, $options: "i" } },
          ],
        }
      : {};

    const cursor = col.aggregate([
      { $match: q },
      {
        $project: {
          _id: { $toString: "$_id" },
          userId: 1,
          nombre: {
            $concat: [
              { $ifNull: ["$nombres", ""] },
              " ",
              { $ifNull: ["$apellidos", ""] },
            ],
          },
          correo: 1,
          estado: 1,
          rol: 1,
        },
      },
      { $sort: { nombre: 1 } },
    ]);

    const docs = await cursor.toArray();
    res.json({ ok: true, data: docs });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// POST /api/usuarios
router.post("/", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("usuarios");
    const parsed = usuarioSchemaCreate.parse(req.body);

    // Normaliza rol/rol_id (acepta cualquiera de los dos)
    const withRole = await normalizeRole(db, { ...parsed });

    // Especialidad siempre array
    const especialidad = Array.isArray(withRole.especialidad)
      ? withRole.especialidad
      : withRole.especialidad
      ? [withRole.especialidad]
      : [];

    // ¡OJO!: fechas como Date, no string
    const now = new Date();
    const doc = {
      ...withRole,
      especialidad,
      createdAt: now,
      updatedAt: now,
    };

    const r = await col.insertOne(doc);
    return res.status(201).json({ ok: true, id: r.insertedId.toString() });
  } catch (e) {
    // si el validador o índice único falla, cae aquí
    return res.status(400).json({ ok: false, error: e.message });
  }
});

// PATCH /api/usuarios/:id
router.patch("/:id", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("usuarios");
    const patch = usuarioSchemaPatch.parse(req.body);

    // Filtro por :id (ObjectId) o por userId si lo mandan en el body
    const filter = patch.userId
      ? { userId: patch.userId }
      : (() => {
          const oid = oidMaybe(req.params.id);
          if (!oid) throw new Error("id inválido");
          return { _id: oid };
        })();

    // Primero normalizamos rol/rol_id a partir del patch
    const normPatch = await normalizeRole(db, { ...patch });

    const $set = { updatedAt: new Date() };

    for (const k of [
      "nombres",
      "apellidos",
      "correo",
      "estado",
      "rol",
      "rol_id",       // <- ahora SÍ actualizamos rol_id
      "direccion",
      "telefono",
    ]) {
      if (normPatch[k] != null) $set[k] = normPatch[k];
    }

    if (normPatch.especialidad != null) {
      $set.especialidad = Array.isArray(normPatch.especialidad)
        ? normPatch.especialidad
        : [normPatch.especialidad];
    }

    // Si no hay nada real para actualizar, devuelvo 400
    const keysToUpdate = Object.keys($set).filter((k) => k !== "updatedAt");
    if (keysToUpdate.length === 0) {
      return res
        .status(400)
        .json({ ok: false, error: "Nada para actualizar" });
    }

    const r = await col.updateOne(filter, { $set });
    if (r.matchedCount === 0) {
      return res.status(404).json({ ok: false, error: "Usuario no encontrado" });
    }
    return res.json({ ok: true, modified: r.modifiedCount });
  } catch (e) {
    return res.status(400).json({ ok: false, error: e.message });
  }
});

// DELETE /api/usuarios/:id
router.delete("/:id", async (req, res) => {
  try {
    const db = await connect();
    const col = db.collection("usuarios");
    const oid = oidMaybe(req.params.id);
    if (!oid) return res.status(400).json({ ok: false, error: "id inválido" });

    const r = await col.deleteOne({ _id: oid });
    if (r.deletedCount === 0) {
      return res.status(404).json({ ok: false, error: "Usuario no encontrado" });
    }
    res.json({ ok: true, deleted: r.deletedCount });
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

module.exports = router;
