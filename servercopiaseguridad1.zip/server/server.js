const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
dotenv.config();

const apiKeyAuth = require("./middlewares/auth");
const usuarios = require("./routes/usuarios");
const pacientes = require("./routes/pacientes");

// 🔽 nuevas rutas
const citas = require("./routes/citas");
const historias = require("./routes/historias");
const ordenesCompras = require("./routes/ordenes_compras");
const ordenesLab = require("./routes/ordenes_laboratorio");

const app = express();
app.use(cors());
app.use(express.json());

// health
app.get("/health", (req, res) => res.json({ ok: true, ts: Date.now() }));

// Auth por API key para todas las rutas /api/*
app.use("/api", apiKeyAuth);

// Rutas
app.use("/api/usuarios", usuarios);
app.use("/api/pacientes", pacientes);
app.use("/api/citas", citas);
app.use("/api/historias", historias);
app.use("/api/ordenes-compras", ordenesCompras);
app.use("/api/ordenes-laboratorio", ordenesLab);

// Not found
app.use((req, res) => res.status(404).json({ ok: false, error: "Not found" }));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`DentalFlow server running on http://localhost:${PORT}`);
});
